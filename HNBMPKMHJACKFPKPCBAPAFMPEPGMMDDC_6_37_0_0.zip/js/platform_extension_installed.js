(()=>{var e={};(function(){window.postMessage({message:"honorlock:extension:installed"},"*")})()})();
